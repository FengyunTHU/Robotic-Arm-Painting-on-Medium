
RAIDUS:float = 90.00 # mm，培养基直径
