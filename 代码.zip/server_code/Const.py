from math import pi

RAIDUS:float = 65.00 # mm，培养基直径
PI:float = pi